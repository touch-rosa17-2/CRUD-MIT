<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../sppFile/bootstrap-5.3.0-alpha1-dist/css/bootstrap.min.css">
    <title>Update</title>
</head>
<body>
    <div class="container">
        <form action="" method="POST">
            <div class="row bg-warning">
                <h1>Update category</h1>
            </div>
            <div class="row pt-4 pb-4 bg-success" >
                <div class="col-lg-3">
                    <label for="updateCategory">Input Category</label>
                    <input type="text" name="updateCategory" id="updateCategory" 
                    value="<?php echo $_GET['category']; ?>">
                </div>
                <div class="col-lg-1">
                    <button type="submit" name="btnUpdate" class="btn btn-primary ">Update</button>
                    <!-- <input type="submit" name="btnSubmit"> -->
                </div>
            </div>
        </form> 
        <?php
            require "config.php";
            $object = new myclass();
            $id = $_GET["id"];
            
            if(isset($_POST["btnUpdate"])){
                $updateCategory = $_POST["updateCategory"];
                // echo 
                // "<script> alert('Update is : $updateCategory');</script>";
                if(empty($updateCategory)){
                    echo "Please update first...";
                }
                else{
                    // normal without function 
                    // $sql = "UPDATE mit_tbl_test SET category='$updateCategory' WHERE id='$id' ";
                    // $query = $object -> link() -> query($sql);

                    //using function
                    $table = "mit_tbl_test";
                    $field = array("category");
                    $value = array("'$updateCategory'");
                    $query = $object -> updateCategory($table, $field, $value, "id", "$id");
                    if($query){
                        echo
                        "<script> alert('Update successfully ...');</script>";
                        header ("refresh:1, url= index.php");
                        ob_end_flush();
                    }
                    else{
                        echo "Please update...";
                    }
                }
            }
        ?>
    </div>
</body>
</html>