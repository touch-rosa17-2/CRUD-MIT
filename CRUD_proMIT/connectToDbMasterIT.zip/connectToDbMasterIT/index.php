<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../sppFile/bootstrap-5.3.0-alpha1-dist/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body class="bg-secondary">
    <div class="container">
        <!-- ============Input Data================ -->
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="POST">
            <div class="row bg-warning">
                <h1>Add category</h1>
            </div>
            <div class="row pt-4 pb-4 bg-success" >
                <div class="col-lg-3">
                    <label for="category">Input Category</label>
                    <input type="text" name="category" id="category" value="">
                </div>
                <div class="col-lg-1">
                    <button type="submit" name="btnSubmit" class="btn btn-primary ">Submit</button>
                    <!-- <input type="submit" name="btnSubmit"> -->
                </div>
            </div>
        </form>

    
        <?php
            require "config.php";
            
            //create object from class
            $object = new myclass;
            if(isset($_POST["btnSubmit"])){
                $category = $_POST["category"];
                if(empty($category)){
                    echo
                    "<script> alert('Please enter category name...');</script>";
                }
                else{
                    //normal
                    // $sql = "INSERT INTO mit_tbl_test(category) VALUES('$category')";
                    // $query = $object->insert('mit_tbl_test');
                    // $query = $object -> link() ->query($sql);


                    //use function instead
                    $field = array("category");
                    $value = array("'$category'");
                    $table = "mit_tbl_test";
                    $query = $object->insert($table,$field,$value); 
                    if($query){
                        echo 
                        "<script> alert('Success...');</script>";
                    }
                    else{
                        echo
                        "<script> echo('Already have...');</script>";
                    }
                }
            }
        ?>
        <!-- ====Output Data======= -->
        <div class="row">
            <div class="col-lg-12  ">
                <table class="table table-hover table-bordered table-success">
                    <tr>
                        <th>ID</th>
                        <th>Category</th>
                        <th colspan="2" class="text-center">Option</th>
                    </tr>
                    <?php
                        // $sql = "SELECT * FROM mit_tbl_test";
                        
                        // normal
                        // $query = $object -> link() -> query($sql);

                        //use function
                        $query = $object -> display("mit_tbl_test");
                        $i=0;//to make id run from 1
                         
                        while($row = mysqli_fetch_assoc(($query))){
                            $i++;
                            $id = $row["id"];
                            $category = $row["category"];
                    ?>
                        <tr>
                            <td>
                                <?php echo $i; ?>
                            </td>
                            <td>
                                <?php echo $category; ?>
                            </td>
                            <td>
                                <a href="updateCategory.php?id=<?php echo $id; ?>& category=<?php echo $category;?>">Update</a>
                            </td>
                            <td>
                                <a href="deleteCategory.php?id=<?php echo $id; ?>&category=<?php echo $category; ?>">Delete</a>
                            </td>.
                        </tr>
                    <?php
                    //look at the top u must see this 
                        }
                    ?>
                </table>
            </div>
        </div>
    </div>
</body>
</html>