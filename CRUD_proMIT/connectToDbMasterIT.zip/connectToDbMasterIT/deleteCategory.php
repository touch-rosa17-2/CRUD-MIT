<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../sppFile/bootstrap-5.3.0-alpha1-dist/css/bootstrap.min.css">
    <title>Delete</title>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class=" p-4 col-lg-12 bg-warning bg-gradient">
                <h1>Delete Category</h1>
            </div>
        </div>
        <div class="row bg-secondary text-white p-3">
            <div class="col-lg-12">
                <h3>Are you sure want to delete this category (<?php echo $_GET['category']; ?>) ?</h3>
            </div>
            <div class="col-lg-4 p-2 text-end ">
                <a href="index.php" class="btn btn-warning ">Cancel</a>
            </div>
            <div class="col-lg-8 p-2">
                
                <form action="" method="POST">
                    <input type="submit" name="btnDelete" class="btn btn-danger" value="Delete">
                </form>
            </div>
        </div>
        <?php
            require "config.php";
            $object = new myclass;

            // if($_SERVER["REQUEST_METHOD"] == "POST"){
            if(isset($_POST["btnDelete"])){
                $id = $_GET["id"];
                $table = "mit_tbl_test";

                //normal without function
                // $sql = "DELETE FROM $table WHERE id=$id";
                // $query = $object->link()->query($sql);

                //using function
                $query = $object->deleteCategory($table,"id",$id);
                if($query){
                    echo
                    "<script> alert('Delete successfully...');</script>";
                    header ("refresh:1, url=index.php");
                }
            } 

        ?>
    </div>
</body>
</html>